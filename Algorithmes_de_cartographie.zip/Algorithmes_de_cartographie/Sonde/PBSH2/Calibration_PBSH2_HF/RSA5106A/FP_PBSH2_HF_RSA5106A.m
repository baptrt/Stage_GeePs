%%This Perfromance Factor value is valid without any amplifier connected to the RSA51206A spectrum analyzer

%Don't use it, it isn't accurate

function FP = FP_PBSH2_HF_RSA5106A(f)

if f>= 5e6 && f<= 50e6
    FP = 19.76*log10(f) - 167.02;
else 
    error('FP_PBSH2:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end 
