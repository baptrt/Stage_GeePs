%%This Perfromance Factor value is valid without any amplifier connected to the R3261C spectrum analyzer

function FP = FP_PBSH2_HF_R3261C(f)

if f>=500e3 && f<= 50e6
    FP = 20.23*log10(f) - 179.17;
else 
    error('FP_PBSH2_piecewise:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end 