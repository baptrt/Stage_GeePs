%%This Perfromance Factor value is valid with the Miteq amplifier connected to the RSA5106A spectrum analyzer

function FP = FP_PBSH2_piecewise_BF(f)

if f >= 5e2 && f < 1e4 
    FP = 15.66*log10(f) - 115.07;
elseif f >= 1e4 && f <= 1e5 
    FP = 7.22*log10(f) - 81.49;
elseif f > 1e5 && f <= 1e7
    FP = 19.13*log10(f) - 140.30;
else 
    error('FP_PBSH2_piecewise:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end