%%This Perfromance Factor value is valid with the Miteq amplifier connected to the RSA5106A spectrum analyzer

function FP = FP_PBSH3_piecewise_BF(f)

if f >= 5e2 && f < 1e4 
    FP = 17.03*log10(f) - 96.60;
elseif f >= 1e4 && f <= 1e5 
    FP = 9.75*log10(f) - 68.59;
elseif f > 1e5 && f <= 1e7
    FP = 20.35*log10(f) - 122.75;
else 
    error('FP_PBSH3_piecewise:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end