%%This Perfromance Factor value is valid without any amplifier connected to the RSA51206A spectrum analyzer

%Don't use it, it isn't accurate

function FP = FP_PBSH3_HF_RSA5106A(f)

if f >= 5e6 && f <= 5e7 
    FP = 18.78*log10(f) - 147.62;
else 
    error('FP_PBSH3:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end