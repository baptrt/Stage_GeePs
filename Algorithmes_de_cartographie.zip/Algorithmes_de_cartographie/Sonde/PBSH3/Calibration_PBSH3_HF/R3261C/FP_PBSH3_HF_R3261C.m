%%This Perfromance Factor value is valid without any amplifier connected to the R3261C spectrum analyzer

function FP = FP_PBSH3_HF_R3261C(f)

if f >= 3e6 && f <= 5e7 
    FP = 39.45*log10(f) - 347.82;
else 
    error('FP_PBSH3:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end