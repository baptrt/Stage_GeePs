%%This Perfromance Factor value is valid with the Miteq amplifier connected to the RSA5106A spectrum analyzer

function FP = FP_CHASE_piecewise(f)

if f >= 9e2 && f <= 1e5 
    FP = 9.63*log10(f) - 72.02;
elseif f > 1e5 && f <= 5e6 
    FP = 19.72*log10(f) - 122.44;
else 
    error('FP_PBSH3_piecewise:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end