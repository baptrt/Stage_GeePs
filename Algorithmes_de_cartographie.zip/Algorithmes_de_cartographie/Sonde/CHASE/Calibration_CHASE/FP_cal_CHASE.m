function FP = FP_cal_CHASE(P_dBm)

% Constants
V = 5;
Zc = 50;
h = 2.05e-3;
a = 1.5e-3;
P = V^2 / (2 * Zc);
n = sqrt(h^2 - a^2);
epsilon_0 = 8.854187817e-12;
mu_0 = 4 * pi * 1e-7;
c = 299792458;
Z = sqrt(epsilon_0 / mu_0);
K = sqrt(Zc * P * 2) / (log((h + n) / (h - n)));
eta = 1 / Z;

% Functions
champ_z = @(r, theta, zy, zz) 8 * K * (r .* sin(theta) + zy) .* zz .* n ./ ...
    (eta * ((r .* sin(theta) + zy).^2 + (zz + n).^2) .* ((r .* sin(theta) + zy).^2 + (zz - n).^2));

y0 = -0.01498; 
z0 = 0.01486; 

FP = P_dBm - 20*log10(abs(champ_z(0, 0, y0, z0)));
end
