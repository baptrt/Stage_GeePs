function FP = FP_CHASE(f)

FP = 16.51*log10(f) - 103.23;