%%This Perfromance Factor value is valid without any amplifier connected to the R3261C spectrum analyzer

function FP = FP_Jaune_HF_R3261C(f)

if 5e5 && 5e7
    FP = 19.10*log10(f) - 149.47;
else 
    error('FP_Jaune:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end