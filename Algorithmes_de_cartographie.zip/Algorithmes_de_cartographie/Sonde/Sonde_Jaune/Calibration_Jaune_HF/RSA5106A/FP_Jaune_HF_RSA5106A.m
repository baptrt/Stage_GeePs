%%This Perfromance Factor value is valid without any amplifier connected to the RSA51206A spectrum analyzer

%Don't use it, it isn't accurate

function FP = FP_Jaune_HF_RSA5106A(f)

if 5e6 && 5e7
    FP = 48.77*log10(f) - 383.80;
else 
    error('FP_Jaune:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end