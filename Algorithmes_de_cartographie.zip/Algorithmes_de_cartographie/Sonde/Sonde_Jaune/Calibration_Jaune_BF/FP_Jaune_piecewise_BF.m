%%This Perfromance Factor value is valid with the Miteq amplifier connected to the RSA5106A spectrum analyzer

function FP = FP_Jaune_piecewise_BF(f)

if f >= 5e2 && f < 1e4 
    FP = 17.41*log10(f) - 96.25;
elseif f >= 1e4 && f < 1e5 
    FP = 9.94*log10(f) - 67.53;
elseif f >= 1e5 && f <= 7e5
    FP = 19.32*log10(f) - 114.37;
else 
    error('FP_Jaune:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end