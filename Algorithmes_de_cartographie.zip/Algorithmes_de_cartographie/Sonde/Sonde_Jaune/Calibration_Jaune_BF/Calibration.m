function CL = Calibration(f)
    % Charger les données depuis le fichier spécifié
    load(f);

    [m, ~] = size(frequences);

    Max_Hz = [];

    % Boucle sur toutes les mesures de fréquence
    for i = 1:m
        % Extraire les données de mesure
        Puis_z = mesure{i, 1};
        
        % Vérifier et convertir si nécessaire
        if iscell(Puis_z)
            Puis_z = cell2mat(Puis_z);
        end
        
        % Vérifier si les données sont numériques
        if isnumeric(Puis_z)
            % Trouver la valeur maximale
            M = max(Puis_z(:)); 
            % Ajouter la valeur maximale au tableau
            Max_Hz = [Max_Hz, M]; 
        else
            error('Les données de mesure ne sont pas dans un format numérique compatible.');
        end
    end

    % Trouver la valeur maximale globale et son index correspondant
    [x, y] = max(Max_Hz);

    % Récupérer la puissance mesurée pour l'index maximal
    Pm = mesure{y, 1};
    
    % Vérifier et convertir si nécessaire
    if iscell(Pm)
        Pm = cell2mat(Pm);
    end

    % Obtenir la fréquence correspondante
    freq = frequences(y, 1);

    % Retourner le facteur de calibration et la fréquence correspondante
    CL = [freq, Pm];
end
