%%This Perfromance Factor value is valid without any amplifier connected to the RSA51206A spectrum analyzer

%Don't use it, it isn't accurate

function FP = FP_PBSH1_HF_RSA5106A(f)

if f>=5e6 && 50e6
    FP = 19.39*log10(f) - 197.21;
else 
    error('FP_PBSH1:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end 