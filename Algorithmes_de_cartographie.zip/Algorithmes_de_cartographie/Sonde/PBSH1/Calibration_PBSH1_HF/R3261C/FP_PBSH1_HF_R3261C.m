%%This Perfromance Factor value is valid without any amplifier connected to the R3261C spectrum analyzer

function FP = FP_PBSH1_HF_R3261C(f)
if f >= 1e6 && f <= 50e6
    FP = 21.23*log10(f) - 210.92;
else 
    error('FP_PBSH1:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end 
