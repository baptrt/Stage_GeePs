function FP = FP_cal_PBSH1(P_dBm)

% Constants
V = 5;
Zc = 50;
h = 2.05e-3;
a = 1.5e-3;
P = V^2 / (2 * Zc);
n = sqrt(h^2 - a^2);
epsilon_0 = 8.854187817e-12;
mu_0 = 4 * pi * 1e-7;
c = 299792458;
Z = sqrt(epsilon_0 / mu_0);
K = sqrt(Zc * P * 2) / (log((h + n) / (h - n)));
eta = 1 / Z;

% Functions
champ_z = @(r, theta, zy, zz) 8 * K * (r .* sin(theta) + zy) .* zz .* n ./ ...
    (eta * ((r .* sin(theta) + zy).^2 + (zz + n).^2) .* ((r .* sin(theta) + zy).^2 + (zz - n).^2));

% Integration limits
R = 0.006 / 2; % Probe radius
r_lower = 0;
r_upper = R;
t_lower = 0;
t_upper = 2 * pi;

y0 = -0.01498; 
z0 = 0.01486; 

% Discretize the domain
num_points = 200;
r_values = linspace(r_lower, r_upper, num_points);
theta_values = linspace(t_lower, t_upper, num_points);

% Initialize arrays
Z_values = zeros(num_points, num_points);

% Evaluate the function on the grid
for i = 1:num_points
    for j = 1:num_points
        Z_values(i, j) = champ_z(r_values(i), theta_values(j), y0, z0);
    end
end

% Calculate mean value
moyenne = mean(Z_values, 'all');

FP = P_dBm - 20*log10(abs(moyenne));
end
