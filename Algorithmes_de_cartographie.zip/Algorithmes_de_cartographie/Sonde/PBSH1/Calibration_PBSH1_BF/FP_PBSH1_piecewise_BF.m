%%This Perfromance Factor value is valid with the Miteq amplifier connected to the RSA5106A spectrum analyzer

function FP = FP_PBSH1_piecewise_BF(f)

if f >= 1e4 && f <= 3e5 
    FP = 6.69*log10(f) - 89.24;
elseif f > 3e5 && f <= 1e7
    FP = 18.65*log10(f) - 156.16;
else 
    error('FP_PBSH2_piecewise:OutOfRange', 'Frequency doesn''t fit with probe operating range');
end