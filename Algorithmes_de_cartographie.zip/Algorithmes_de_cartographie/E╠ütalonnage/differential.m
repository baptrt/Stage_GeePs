% Définir les constantes
syms Zc P h n f Z K eta y z

% Définir la fonction champ_z
champ_z = @(y, z) 8 * K * y * z * n / ...
    (eta * (y^2 + (z + n)^2) * (y^2 + (z - n)^2));

champ_y = @(y, z) (-4 * K * (y^2 - z^2 + n^2) * n) /...
    (eta * (y^2 + (z + n)^2) * (y^2 + (z - n)^2));

% Calcul des dérivées partielles
deriv_z_y = diff(champ_z(y, z), y);
deriv_z_z = diff(champ_z(y, z), z);

deriv_y_y = diff(champ_y(y, z), y);
deriv_y_z = diff(champ_y(y, z), z);

% Affichage des résultats
fprintf('La différentielle de H_z(y,z) par rapport à y est : \n');
disp(deriv_z_y);

fprintf('La différentielle de H_z(y,z) par rapport à z est : \n');
disp(deriv_z_z);

fprintf('La différentielle de H_y(y,z) par rapport à y est : \n');
disp(deriv_y_y);

fprintf('La différentielle de H_y(y,z) par rapport à z est : \n');
disp(deriv_y_z);