function H = Calcul(frequences, mesure, FP)

[m, n] = size(frequences); %fréquences présentent dans le fichier de mesure

% Initialiser un tableau pour stocker les champs magnétiques maximum
H = [];

for i = 1:m
    Puis_z = mesure(i); % Extraire les données de mesure
    H_db = Puis_z - FP; % Soustraire le facteur de performance
    H = [H, 10.^(H_db ./ 20)]; % Convertir dB A/m en A/m
end
